1.Connect RFID Modules to MEGA2560
2. Open Arduino File (sketch_sep04a.ino)
3. Compile and Upload 
4. Make IC Card over on RFID Modules