1. Test.hex RC522.hex are used for STM8,write one of them into STM8.
2. Test.hex are use with arduino for test.
3. RC522.hex are use with PC Software for test.
